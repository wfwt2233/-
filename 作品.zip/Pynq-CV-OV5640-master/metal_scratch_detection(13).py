import cv2
import numpy as np
import os
import glob
import matplotlib.pyplot as plt
from scipy import ndimage
from scipy import stats
import gc

class EnhancedMetalScratchDetection:
    def __init__(self, image_folder='/home/xu/metal_scratch_detection/data'):
        self.image_folder = image_folder
        self.images_path = []
        
        # 平衡的检测参数
        self.scratch_threshold = 0.005    # 适中的边缘比例阈值
        self.min_scratch_area = 30        # 适中的最小面积
        self.min_components = 1           # 适中的最小组件数量
        
        # 划痕特征分析参数
        self.min_aspect_ratio = 2.5       # 适中的长宽比
        self.min_scratch_length = 15      # 适中的最小长度
        self.min_depth_score = 8          # 适中的深度要求
        
        # 显示模式
        self.verbose_mode = True
        self.max_image_size = (800, 600)
        
        self.load_images()
    
    def load_images(self):
        """Load images"""
        supported_formats = ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff']
        for fmt in supported_formats:
            pattern = os.path.join(self.image_folder, fmt)
            self.images_path.extend(glob.glob(pattern))
        
        print(f"📁 Found {len(self.images_path)} images")
        if self.verbose_mode:
            for img_path in self.images_path:
                print(f"   - {os.path.basename(img_path)}")
    
    def load_single_image(self, image_path):
        """Load single image"""
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image not found: {image_path}")
        
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Cannot read image: {image_path}")
        
        # 调整图像尺寸
        if image.shape[0] > self.max_image_size[1] or image.shape[1] > self.max_image_size[0]:
            scale = min(self.max_image_size[0] / image.shape[1], 
                       self.max_image_size[1] / image.shape[0])
            new_width = int(image.shape[1] * scale)
            new_height = int(image.shape[0] * scale)
            image = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)
        
        return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    def enhanced_scratch_detection(self, image):
        """增强的划痕检测算法"""
        # 转换为灰度图
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        
        # 多尺度处理
        results = []
        for sigma in [1, 2, 3]:
            # 高斯模糊
            blurred = cv2.GaussianBlur(gray, (0, 0), sigma)
            
            # 多方向边缘检测
            edges_x = cv2.Sobel(blurred, cv2.CV_64F, 1, 0, ksize=3)
            edges_y = cv2.Sobel(blurred, cv2.CV_64F, 0, 1, ksize=3)
            edges_magnitude = np.sqrt(edges_x**2 + edges_y**2)
            
            # 自适应阈值
            threshold = np.mean(edges_magnitude) + 2 * np.std(edges_magnitude)
            binary = (edges_magnitude > threshold).astype(np.uint8) * 255
            
            results.append(binary)
        
        # 合并多尺度结果
        combined = np.zeros_like(results[0])
        for result in results:
            combined = cv2.bitwise_or(combined, result)
        
        return gray, combined
    
    def analyze_scratch_features(self, binary_image, gray_image):
        """分析划痕特征"""
        height, width = binary_image.shape
        
        # 连通组件分析
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
            binary_image, connectivity=8)
        
        valid_scratches = []
        total_scratch_area = 0
        
        for i in range(1, num_labels):
            area = stats[i, cv2.CC_STAT_AREA]
            
            if area >= self.min_scratch_area:
                # 提取组件轮廓
                component_mask = (labels == i).astype(np.uint8) * 255
                contours, _ = cv2.findContours(component_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                
                if contours:
                    contour = contours[0]
                    
                    # 分析形状特征
                    x, y, w, h = cv2.boundingRect(contour)
                    aspect_ratio = max(w, h) / min(w, h) if min(w, h) > 0 else 0
                    length = max(w, h)
                    
                    # 分析深度特征
                    mask = np.zeros(gray_image.shape, np.uint8)
                    cv2.drawContours(mask, [contour], 0, 255, -1)
                    
                    scratch_pixels = gray_image[mask == 255]
                    if len(scratch_pixels) > 0:
                        scratch_mean = np.mean(scratch_pixels)
                        
                        # 获取周围区域
                        kernel = np.ones((20, 20), np.uint8)
                        dilated_mask = cv2.dilate(mask, kernel, iterations=2)
                        surrounding_mask = cv2.bitwise_xor(dilated_mask, mask)
                        surrounding_pixels = gray_image[surrounding_mask == 255]
                        
                        if len(surrounding_pixels) > 0:
                            surrounding_mean = np.mean(surrounding_pixels)
                            depth_score = abs(surrounding_mean - scratch_mean)
                            
                            # 验证划痕特征
                            is_valid = (
                                aspect_ratio >= self.min_aspect_ratio and
                                length >= self.min_scratch_length and
                                depth_score >= self.min_depth_score
                            )
                            
                            if is_valid:
                                valid_scratches.append(i)
                                total_scratch_area += area
        
        return valid_scratches, total_scratch_area
    
    def detect_single_image(self, image_path=None, show_plot=True, save_results=True):
        """检测单张图像"""
        if image_path is None and self.images_path:
            image_path = self.images_path[0]
        
        if not image_path:
            raise ValueError("No available image path")
        
        try:
            # 加载图像
            original_image = self.load_single_image(image_path)
            image_name = os.path.basename(image_path)
            
            print(f"🔍 Detecting image: {image_name}")
            print(f"   Image size: {original_image.shape}")
            
            # 预处理和边缘检测
            gray_image, binary_image = self.enhanced_scratch_detection(original_image)
            
            # 分析划痕特征
            valid_scratches, total_scratch_area = self.analyze_scratch_features(binary_image, gray_image)
            
            # 基本统计
            height, width = binary_image.shape
            edge_area = np.sum(binary_image == 255)
            total_area = height * width
            edge_ratio = edge_area / total_area
            
            # 划痕判定
            has_scratch = (edge_ratio > self.scratch_threshold and 
                          len(valid_scratches) >= self.min_components)
            
            # 严重程度评估
            if has_scratch:
                severity_ratio = total_scratch_area / total_area
                if severity_ratio < 0.001:
                    severity = "Minor Scratch"
                elif severity_ratio < 0.005:
                    severity = "Moderate Scratch"
                else:
                    severity = "Severe Scratch"
            else:
                severity = "No Scratch"
            
            result = {
                'status': "NG" if has_scratch else "OK",
                'edge_ratio': edge_ratio,
                'valid_scratch_count': len(valid_scratches),
                'total_scratch_area': total_scratch_area,
                'severity': severity,
                'severity_score': edge_ratio * 100
            }
            
            # 显示结果
            print(f"📊 Detection results:")
            print(f"   Status: {result['status']}")
            print(f"   Severity: {result['severity']}")
            print(f"   Edge ratio: {result['edge_ratio']:.6f}")
            print(f"   Valid scratches: {result['valid_scratch_count']}")
            print(f"   Total scratch area: {result['total_scratch_area']} pixels")
            
            # 可视化
            if show_plot:
                self.create_visualization(original_image, binary_image, result, image_name)
            
            return result
            
        except Exception as e:
            print(f"❌ Error detecting image: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def create_visualization(self, original_image, binary_image, result, image_name):
        """创建可视化"""
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        fig.suptitle(f'Scratch Detection - {image_name}\nResult: {result["status"]} - {result["severity"]}', 
                    fontsize=14, fontweight='bold')
        
        # 原图
        axes[0].imshow(original_image)
        axes[0].set_title('Original Image')
        axes[0].axis('off')
        
        # 边缘检测结果
        axes[1].imshow(binary_image, cmap='gray')
        axes[1].set_title('Edge Detection')
        axes[1].axis('off')
        
        # 检测结果
        overlay = original_image.copy()
        if result['status'] == 'NG':
            # 在实际应用中，这里会绘制检测到的划痕
            pass
        
        axes[2].imshow(overlay)
        axes[2].set_title('Detection Result')
        axes[2].axis('off')
        
        plt.tight_layout()
        plt.show()
    
    def detect_multiple_images(self, image_paths=None, show_plot=False, save_results=True):
        """检测多张图像"""
        if image_paths is None:
            image_paths = self.images_path
        
        if not image_paths:
            print("❌ No images available for detection")
            return []
        
        results = []
        print(f"🔄 Processing {len(image_paths)} images...")
        
        for i, image_path in enumerate(image_paths, 1):
            print(f"\n[{i}/{len(image_paths)}] Processing: {os.path.basename(image_path)}")
            
            try:
                result = self.detect_single_image(image_path, show_plot=show_plot, save_results=save_results)
                results.append({
                    'image_path': image_path,
                    'result': result
                })
            except Exception as e:
                print(f"❌ Failed: {e}")
                results.append({
                    'image_path': image_path,
                    'error': str(e)
                })
        
        # 生成报告
        self.generate_report(results)
        return results
    
    def generate_report(self, results):
        """生成检测报告"""
        total = len(results)
        successful = len([r for r in results if 'result' in r and r['result']])
        ng_count = len([r for r in results if 'result' in r and r['result'] and r['result']['status'] == 'NG'])
        ok_count = successful - ng_count
        
        print("\n" + "="*50)
        print("📊 DETECTION REPORT")
        print("="*50)
        print(f"Total images: {total}")
        print(f"Successfully processed: {successful}")
        print(f"OK (No scratches): {ok_count}")
        print(f"NG (With scratches): {ng_count}")
        print(f"Defect rate: {(ng_count/successful*100 if successful > 0 else 0):.1f}%")
        print("="*50)
    
    def interactive_test(self):
        """交互式测试"""
        print("🎯 Scratch Detection Testing")
        print("="*40)
        
        while True:
            print("\nOptions:")
            print("1. Test single image")
            print("2. Test all images")
            print("3. Change parameters")
            print("4. Exit")
            
            choice = input("\nSelect option (1-4): ").strip()
            
            if choice == '1':
                if not self.images_path:
                    print("❌ No images found")
                    continue
                
                print("\nAvailable images:")
                for i, img_path in enumerate(self.images_path, 1):
                    print(f"{i}. {os.path.basename(img_path)}")
                
                try:
                    idx = int(input(f"\nSelect image (1-{len(self.images_path)}): ")) - 1
                    if 0 <= idx < len(self.images_path):
                        self.detect_single_image(self.images_path[idx], show_plot=True)
                    else:
                        print("❌ Invalid selection")
                except ValueError:
                    print("❌ Please enter a valid number")
            
            elif choice == '2':
                self.detect_multiple_images(show_plot=False)
            
            elif choice == '3':
                self.adjust_parameters()
            
            elif choice == '4':
                print("👋 Goodbye!")
                break
            
            else:
                print("❌ Invalid choice")
    
    def adjust_parameters(self):
        """调整参数"""
        print("\nCurrent parameters:")
        print(f"1. Scratch threshold: {self.scratch_threshold}")
        print(f"2. Min scratch area: {self.min_scratch_area}")
        print(f"3. Min components: {self.min_components}")
        print(f"4. Min aspect ratio: {self.min_aspect_ratio}")
        print(f"5. Min scratch length: {self.min_scratch_length}")
        print(f"6. Min depth score: {self.min_depth_score}")
        
        try:
            choice = input("\nSelect parameter to change (1-6) or 'c' to cancel: ").strip()
            if choice == 'c':
                return
            
            choice = int(choice)
            if choice == 1:
                self.scratch_threshold = float(input(f"New threshold (current: {self.scratch_threshold}): "))
            elif choice == 2:
                self.min_scratch_area = int(input(f"New min area (current: {self.min_scratch_area}): "))
            elif choice == 3:
                self.min_components = int(input(f"New min components (current: {self.min_components}): "))
            elif choice == 4:
                self.min_aspect_ratio = float(input(f"New min aspect ratio (current: {self.min_aspect_ratio}): "))
            elif choice == 5:
                self.min_scratch_length = int(input(f"New min length (current: {self.min_scratch_length}): "))
            elif choice == 6:
                self.min_depth_score = int(input(f"New min depth score (current: {self.min_depth_score}): "))
            else:
                print("❌ Invalid selection")
                return
            
            print("✅ Parameter updated")
            
        except ValueError:
            print("❌ Please enter a valid value")

# 使用示例
def main():
    detector = EnhancedMetalScratchDetection('/home/xu/metal_scratch_detection/data')
    detector.interactive_test()

if __name__ == "__main__":
    main()